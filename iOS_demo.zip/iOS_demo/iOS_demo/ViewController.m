//
//  ViewController.m
//  iOS_demo
//
//  Created by mctc on 2018/3/9.
//  Copyright © 2018年 mctc. All rights reserved.
//

#import "ViewController.h"
#import "XDListOfFriendsViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
  
    
}
- (IBAction)ClickButton:(id)sender {
    XDListOfFriendsViewController *listVC = [[XDListOfFriendsViewController alloc] init];
    [self presentViewController:listVC animated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
