//
//  AppDelegate.h
//  iOS_demo
//
//  Created by mctc on 2018/3/9.
//  Copyright © 2018年 mctc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

