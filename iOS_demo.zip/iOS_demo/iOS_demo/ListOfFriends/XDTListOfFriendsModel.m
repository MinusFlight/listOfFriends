//
//  XDTListOfFriendsModel.m
//  LookFly
//
//  Created by mctc on 2017/12/27.
//  Copyright © 2017年 hxdkengge. All rights reserved.
//

#import "XDTListOfFriendsModel.h"

@implementation XDTListOfFriendsModel

@end
