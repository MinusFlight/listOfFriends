//
//  XDTListOfFriendsCell.m
//  LookFly
//
//  Created by mctc on 2017/12/26.
//  Copyright © 2017年 hxdkengge. All rights reserved.
//

#import "XDTListOfFriendsCell.h"
#import "Masonry.h"

#define image(name) [UIImage imageNamed:name]
#define XDScreenWidth [UIScreen mainScreen].bounds.size.width
#define XDScreenHeight [UIScreen mainScreen].bounds.size.height

@interface XDTListOfFriendsCell ()

@property (nonatomic, strong)  UIImageView *iconImage;

@property (nonatomic, strong)  UILabel *iconTitle;

@end

@implementation XDTListOfFriendsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self setUpUI];
        
    }
    
    return self;
}

- (void)setUpUI {
    self.iconImage = [[UIImageView alloc] init];
    self.iconImage.image = image(@"xiangji");
    _iconImage.layer.cornerRadius = 10;
    _iconImage.clipsToBounds = YES;
    [self.contentView addSubview:_iconImage];
    
    [_iconImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.offset(10);
        make.width.height.offset(50);
        
    }];
    [self.contentView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(_iconImage).offset(10);
    }];

    self.iconTitle = [[UILabel alloc] init];
    self.iconTitle.font = [UIFont systemFontOfSize:14.f];
    [self.contentView addSubview:_iconTitle];
    [_iconTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_iconImage);
        make.left.equalTo(_iconImage.mas_right).offset(15);
    }];
}

- (void)setModel:(XDTListOfFriendsModel *)model {
   self.iconImage.image = image(model.iconImage);
    
    self.iconTitle.text = model.iconTitle;
}

- (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)newsize{
    UIGraphicsBeginImageContext(newsize);
    [img drawInRect:CGRectMake(0, 0, newsize.width, newsize.height)];
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaledImage;
}
@end
