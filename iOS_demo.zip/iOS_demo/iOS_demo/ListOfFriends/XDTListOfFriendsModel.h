//
//  XDTListOfFriendsModel.h
//  LookFly
//
//  Created by mctc on 2017/12/27.
//  Copyright © 2017年 hxdkengge. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XDTListOfFriendsModel : NSObject

@property (nonatomic, copy) NSString *iconImage;

@property (nonatomic, copy) NSString *iconTitle;

@end
