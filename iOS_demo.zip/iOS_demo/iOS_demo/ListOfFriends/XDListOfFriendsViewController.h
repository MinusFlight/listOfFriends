//
//  XDListOfFriendsViewController.h
//  LookFly
//
//  Created by mctc on 2017/12/25.
//  Copyright © 2017年 hxdkengge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XDListOfFriendsViewController : UIViewController

@end
