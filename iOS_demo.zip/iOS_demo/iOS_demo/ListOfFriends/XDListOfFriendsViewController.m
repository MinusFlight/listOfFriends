//
//  XDListOfFriendsViewController.m
//  LookFly
//
//  Created by mctc on 2017/12/25.
//  Copyright © 2017年 hxdkengge. All rights reserved.
//

#import "XDListOfFriendsViewController.h"
#import "Masonry.h"
#import "XDTListOfFriendsCell.h"
#import "XDTListOfFriendsModel.h"

#define image(name) [UIImage imageNamed:name]
#define XDScreenWidth [UIScreen mainScreen].bounds.size.width
#define XDScreenHeight [UIScreen mainScreen].bounds.size.height

@interface XDListOfFriendsViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableview;

@property (nonatomic, assign) BOOL isFrist;

@property (nonatomic, assign) CGFloat imageHeight;

@property (nonatomic, strong) NSMutableArray *dictionaryKeyM;

@property (nonatomic, strong) NSMutableArray *loadDataArrM;

@end

@implementation XDListOfFriendsViewController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];

}
 
- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadDate];
   
    [self makeHeaderImageView];
    
     [self makeListFriendsTableView];
}

- (void)makeHeaderImageView {

    
    
}

- (void)makeListFriendsTableView {

    
    self.tableview = [[UITableView alloc] initWithFrame:CGRectMake(0, 20, XDScreenWidth, XDScreenHeight-20)];
    _tableview.delegate = self;
    _tableview.dataSource = self;
    
    self.tableview.estimatedRowHeight = 70;
    self.tableview.rowHeight = UITableViewAutomaticDimension;

    //设置右边索引
    self.tableview.sectionIndexColor = [UIColor blackColor];
    [self.view addSubview:_tableview];
    
    [_tableview registerClass:[XDTListOfFriendsCell class] forCellReuseIdentifier:@"list_of_friends_cell"];

    
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.dictionaryKeyM.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSString *string = [(NSDictionary *)self.loadDataArrM[section] allKeys].lastObject;
    NSArray *arr = [(NSDictionary *)self.loadDataArrM[section] valueForKey:string];
    return arr.count;
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    XDTListOfFriendsCell *cell = [tableView dequeueReusableCellWithIdentifier:@"list_of_friends_cell" forIndexPath:indexPath];
    NSString *string = [(NSDictionary *)self.loadDataArrM[indexPath.section] allKeys].lastObject;
    NSArray *arr = [(NSDictionary *)self.loadDataArrM[indexPath.section] valueForKey:string];
    
    cell.model = arr[indexPath.row];
    
    return cell;
}

-(NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView {
    
    
    return self.dictionaryKeyM.copy;
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    return self.dictionaryKeyM[section];
}

// 点击索引跳转
-(NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString*)title atIndex:(NSInteger)index {
    
    NSLog(@"%zd--%@", index, title);
    
    return index;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}


- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    
}


- (void)loadDate {
    
    // 模拟数据
    NSArray *arr = @[@{@"iconImage":@"xiangji",@"iconTitle":@"啊"}, @{@"iconImage":@"xiangji",@"iconTitle":@"#明创天成"}, @{@"iconImage":@"xiangji",@"iconTitle":@"比心"}, @{@"iconImage":@"xiangji",@"iconTitle":@"明创天成"}, @{@"iconImage":@"xiangji",@"iconTitle":@"话东风"}, @{@"iconImage":@"xiangji",@"iconTitle":@"z大大"}, @{@"iconImage":@"xiangji",@"iconTitle":@"小明"}, @{@"iconImage":@"xiangji",@"iconTitle":@"😂天成"}, @{@"iconImage":@"xiangji",@"iconTitle":@"🦐咪"}, @{@"iconImage":@"xiangji",@"iconTitle":@"太愤怒"}, @{@"iconImage":@"xiangji",@"iconTitle":@"123456"}, @{@"iconImage":@"xiangji",@"iconTitle":@"zz"}, @{@"iconImage":@"xiangji",@"iconTitle":@"甜美"}, @{@"iconImage":@"xiangji",@"iconTitle":@"太累"}, @{@"iconImage":@"xiangji",@"iconTitle":@"死亡"}, @{@"iconImage":@"xiangji",@"iconTitle":@"打击"}, @{@"iconImage":@"xiangji",@"iconTitle":@"绝地"}, @{@"iconImage":@"xiangji",@"iconTitle":@"求生"}, @{@"iconImage":@"xiangji",@"iconTitle":@"大"}, @{@"iconImage":@"xiangji",@"iconTitle":@"调沙"}];

    NSMutableArray *arrlll = [NSMutableArray array];
    // 字典key
    self.dictionaryKeyM = [NSMutableArray array];

    for (NSDictionary *dict in arr) {
        // 拿到首字符串
        NSString *string = [self firstCharactorWithString:dict[@"iconTitle"]];
        if (![arrlll containsObject:string]) {
            // 保存到数组 中
            [_dictionaryKeyM addObject:string];
            [arrlll addObject:string];
        }
    }
    
    
    //通过自带的compare方法升序排列
    [_dictionaryKeyM sortUsingSelector:@selector(compare:)];
    
//    NSLog(@"%@", _dictionaryKeyM);
    
    //把 # 号放到最后面
    for (NSInteger i = 0; i < _dictionaryKeyM.count; i++) {
        NSString *string = _dictionaryKeyM[i];
        if ([string isEqualToString:@"#"]) {
            [_dictionaryKeyM removeObjectAtIndex:i];
            [_dictionaryKeyM addObject:@"#"];
        }
    }
//    NSLog(@"%@", _dictionaryKeyM);
    
    NSMutableArray *dateArrM = [NSMutableArray array];
    
    // 根据首字符串进行划分 数组里面保存字典 首字母对应的每一相同首字母的成员的数组
    
    // 遍历首字母数组
    for (NSInteger j = 0; j < _dictionaryKeyM.count; j++) {
        NSMutableDictionary *dictM = [NSMutableDictionary dictionary];
        NSMutableArray *lastArrM = [NSMutableArray array];
        // 遍历数据成员
        for (NSInteger i = 0; i < arr.count; i++) {
            NSDictionary *dict = arr[i];
            NSLog(@"%@", dict);
            // 获取成员对应的首字母
            NSString *string = [self firstCharactorWithString:dict[@"iconTitle"]];
            NSLog(@"%@", string);
            
            NSLog(@"%@", _dictionaryKeyM[j]);
            // 将arr成员对应的首字母和保存起来的首字母进行判断
            if ([_dictionaryKeyM[j] isEqualToString:string]) {
                // 相同字典转模型并保存
                XDTListOfFriendsModel *model = [[XDTListOfFriendsModel alloc] init];
                [model setValuesForKeysWithDictionary:dict];
                [lastArrM addObject:model];
            }
        }
        // 再将保存模型的数组 对应首字母
        [dictM setObject:lastArrM forKey:_dictionaryKeyM[j]];
        
        NSLog(@"%@--%@", dictM, lastArrM);
        // 然后添加到数组中
        [dateArrM addObject:dictM];
    }
    
//    NSMutableArray *dateArrM2 = [NSMutableArray array];
//    for (NSInteger i = 0; i < _dictionaryKeyM.count; i++) {
//        NSDictionary *dict = dateArrM[i];
//        if ([_dictionaryKeyM[i] isEqualToString:dict.allKeys.lastObject]) {
//            [dateArrM2 addObject:dict];
//        }
//    }
//
//    NSLog(@"%@", dateArrM2);
    
    self.loadDataArrM = [NSMutableArray array];
    
    self.loadDataArrM = dateArrM;
    
}

//获取某个字符串或者汉字的首字符串 不一定是字母.
- (NSString *)firstCharactorWithString:(NSString *)string {
    
    NSMutableString *str = [NSMutableString stringWithString:string];
    CFStringTransform((CFMutableStringRef) str, NULL, kCFStringTransformMandarinLatin, NO);
    CFStringTransform((CFMutableStringRef)str, NULL, kCFStringTransformStripDiacritics, NO);
    NSString *pinYin = [str capitalizedString];

    //不是首字母规划到#中
    if (![self inputShouldLetter:[pinYin substringToIndex:1]]) {
        
        return @"#";
    }
    
    return [pinYin substringToIndex:1];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// 判断字符串是不是email表情
- (BOOL)stringContainsEmoji:(NSString *)string
{
    __block BOOL returnValue = NO;
    
    [string enumerateSubstringsInRange:NSMakeRange(0, [string length]) options:NSStringEnumerationByComposedCharacterSequences usingBlock:^(NSString *substring, NSRange substringRange, NSRange enclosingRange, BOOL *stop) {
        const unichar hs = [substring characterAtIndex:0];
        if (0xd800 <= hs && hs <= 0xdbff) {
            if (substring.length > 1) {
                const unichar ls = [substring characterAtIndex:1];
                const int uc = ((hs - 0xd800) * 0x400) + (ls - 0xdc00) + 0x10000;
                if (0x1d000 <= uc && uc <= 0x1f77f) {
                    returnValue = YES;
                }
            }
        } else if (substring.length > 1) {
            const unichar ls = [substring characterAtIndex:1];
            if (ls == 0x20e3) {
                returnValue = YES;
            }
        } else {
            if (0x2100 <= hs && hs <= 0x27ff) {
                returnValue = YES;
            } else if (0x2B05 <= hs && hs <= 0x2b07) {
                returnValue = YES;
            } else if (0x2934 <= hs && hs <= 0x2935) {
                returnValue = YES;
            } else if (0x3297 <= hs && hs <= 0x3299) {
                returnValue = YES;
            } else if (hs == 0xa9 || hs == 0xae || hs == 0x303d || hs == 0x3030 || hs == 0x2b55 || hs == 0x2b1c || hs == 0x2b1b || hs == 0x2b50) {
                returnValue = YES;
            }
        }
    }];
    
    return returnValue;
}

// 判断字符串是不是字母
- (BOOL)inputShouldLetter:(NSString *)inputString {
    if (inputString.length == 0) return NO;
    NSString *regex =@"[a-zA-Z]*";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    return [pred evaluateWithObject:inputString];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
