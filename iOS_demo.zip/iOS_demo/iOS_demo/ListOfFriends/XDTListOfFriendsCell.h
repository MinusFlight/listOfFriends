//
//  XDTListOfFriendsCell.h
//  LookFly
//
//  Created by mctc on 2017/12/26.
//  Copyright © 2017年 hxdkengge. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XDTListOfFriendsModel.h"

@interface XDTListOfFriendsCell : UITableViewCell

@property (nonatomic, strong) XDTListOfFriendsModel *model;

@end
